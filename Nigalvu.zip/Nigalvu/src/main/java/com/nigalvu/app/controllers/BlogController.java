package com.nigalvu.app.controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

public class BlogController 
{
	@RequestMapping("blog-single")
	public ModelAndView Blog()
	{
		ModelAndView model = new ModelAndView();
		model.setViewName("blog-single");
		return model;
	}
}
