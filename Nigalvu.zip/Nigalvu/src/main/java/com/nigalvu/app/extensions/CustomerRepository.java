package com.nigalvu.app.extensions;

import org.springframework.data.repository.CrudRepository;

import com.nigalvu.app.models.Customer;

public interface CustomerRepository extends CrudRepository<Customer, Integer>
{

}
