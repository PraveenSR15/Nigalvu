package com.nigalvu.app.controllers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.nigalvu.app.extensions.CustomerRepository;
import com.nigalvu.app.models.Customer;

@Controller
public class HomeController 
{
	@Autowired
	CustomerRepository customerRepository;
	
	@RequestMapping({"home","/"})	
	public ModelAndView Home()
	{
		ModelAndView model = new ModelAndView();
		
		model.setViewName("home");
		
		return model;
	}
	
	@RequestMapping("Login")
	public ModelAndView Login(Customer customer)
	{		
		ModelAndView model = new ModelAndView();
		
		Iterable<Customer> temp = customerRepository.findAll();
		Iterator<Customer> it = temp.iterator();
		while(it.hasNext())
		{
			Customer c = it.next();
			if(c.username.equals(customer.username) && c.password.equals(customer.password))
				model.setViewName("gallery");
			else
				model.setViewName("about");
		}
		return model;
	}
}
