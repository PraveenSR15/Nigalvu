package com.nigalvu.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NigalvuApplication {

	public static void main(String[] args) {
		SpringApplication.run(NigalvuApplication.class, args);
	}

}
