package com.nigalvu.app.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nigalvu.app.extensions.CustomerRepository;
import com.nigalvu.app.models.Customer;

@Controller
public class SignUpController 
{
	@Autowired
	CustomerRepository customerRepository; 
	
	@RequestMapping("signup")
	public ModelAndView Signup()
	{
		ModelAndView model = new ModelAndView();
		model.setViewName("signup");
		return model;
	}
	
	@RequestMapping("createUser")
	public ModelAndView CreateUser(Customer customer)
	{
		System.out.println("customerRepository"+customerRepository);
		customerRepository.save(customer);
		ModelAndView model = new ModelAndView();
		model.setViewName("home");
		return model;
	}
}
